<h1>laralove</h1>
<?php /**PATH C:\xampp\htdocs\task-it20\questionnaire\resources\views/index.blade.php ENDPATH**/ ?>
