<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QuestInfo extends Model
{
    //
}
